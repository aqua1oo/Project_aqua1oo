var searchData=
[
  ['internalmlccallback',['InternalMLCcallback',['../interfacecom_1_1umc_1_1mlctest_1_1_main_activity_1_1_internal_m_l_ccallback.html',1,'com::umc::mlctest::MainActivity']]]
];
