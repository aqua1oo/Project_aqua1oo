var searchData=
[
  ['callbackheight',['callbackheight',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a6856446a09f29a2a0a035bf18859335d',1,'com::umc::mlctest::MlcDispActivity']]],
  ['callbackwidth',['callbackwidth',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#ac40451825b269668dd20f2a0313eda58',1,'com::umc::mlctest::MlcDispActivity']]],
  ['colorformat',['colorFormat',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#a3ca476199cbb0b6b8d80018aa843ad89',1,'com::umc::mlctest::MainActivity']]]
];
