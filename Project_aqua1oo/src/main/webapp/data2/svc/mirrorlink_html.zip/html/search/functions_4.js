var searchData=
[
  ['initsettingdevicestatusbuttons',['initSettingDeviceStatusButtons',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a5532ace9ad70884642cd01d3201d60a9',1,'com::umc::mlctest::MlcDispActivity']]],
  ['isappopened',['isAppOpened',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#a4b8c3b4b51f3452189e0993c43ea15d2',1,'com::umc::mlctest::MainActivity']]]
];
