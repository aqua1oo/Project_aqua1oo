var searchData=
[
  ['disableexitbutton',['disableExitButton',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#ad320dbac341b0216311ee643e9882fb8',1,'com::umc::mlctest::MainActivity']]]
];
