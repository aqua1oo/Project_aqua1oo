var searchData=
[
  ['applistactivity_2ejava',['AppListActivity.java',['../_app_list_activity_8java.html',1,'']]]
];
