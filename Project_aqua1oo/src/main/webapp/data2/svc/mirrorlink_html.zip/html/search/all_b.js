var searchData=
[
  ['setcustomtextfont',['setCustomTextFont',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#a12d66d094e1fe9c2be918bc6f52de8bd',1,'com.umc.mlctest.MainActivity.setCustomTextFont()'],['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a5c5c222186fc8578ad1e6b65670142ef',1,'com.umc.mlctest.MlcDispActivity.setCustomTextFont()']]],
  ['setinternalcb',['setInternalCb',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#adac68fdf297e6a7f44da164618a8f14b',1,'com::umc::mlctest::MainActivity']]],
  ['settingsclickedfromapilayout',['SettingsClickedFromApiLayout',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a550fb9fa3d9d7edbe8e6f91fda35d405',1,'com::umc::mlctest::MlcDispActivity']]],
  ['settingsclickedfrommainlayout',['SettingsClickedFromMainLayout',['../classcom_1_1umc_1_1mlctest_1_1_mlc_set_config_activity.html#ac8952f61debb71a5958cf1eea3520a59',1,'com::umc::mlctest::MlcSetConfigActivity']]],
  ['showupdatedapplist',['showUpdatedAppList',['../classcom_1_1umc_1_1mlctest_1_1_app_list_activity.html#a87186632fb317056b4cedbcd477118d5',1,'com.umc.mlctest.AppListActivity.showUpdatedAppList()'],['../interfacecom_1_1umc_1_1mlctest_1_1_main_activity_1_1_internal_m_l_ccallback.html#a8aebb6994d1bb1880ff55d40f3554347',1,'com.umc.mlctest.MainActivity.InternalMLCcallback.showUpdatedAppList()'],['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a2686d844ccd93abfbf86a85648be06b3',1,'com.umc.mlctest.MlcDispActivity.showUpdatedAppList()']]],
  ['surfacechanged',['surfaceChanged',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a8a82d6860607cfb81691c1eb815b4c01',1,'com::umc::mlctest::MlcDispActivity']]],
  ['surfacecreated',['surfaceCreated',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#ac5cf69550c29b91d08ca5ed6f7045744',1,'com::umc::mlctest::MlcDispActivity']]],
  ['surfacedestroyed',['surfaceDestroyed',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a3b682330ed4eeb1b6028607f953a0baa',1,'com::umc::mlctest::MlcDispActivity']]]
];
