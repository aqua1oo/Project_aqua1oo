var searchData=
[
  ['mappidlaunched',['mAppIdLaunched',['../classcom_1_1umc_1_1mlctest_1_1_app_list_activity.html#a1de774401a496f6e586a9006684525d9',1,'com::umc::mlctest::AppListActivity']]],
  ['mhandle',['mhandle',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#a834bb9af056f88d41b52991718d991bf',1,'com::umc::mlctest::MainActivity']]]
];
