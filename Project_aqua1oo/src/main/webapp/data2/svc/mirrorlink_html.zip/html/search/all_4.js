var searchData=
[
  ['enableexitbutton',['enableExitButton',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#ad1477b1e171f46f57da504941f20da02',1,'com::umc::mlctest::MainActivity']]]
];
