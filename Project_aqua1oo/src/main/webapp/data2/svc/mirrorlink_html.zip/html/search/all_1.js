var searchData=
[
  ['bdatanotavail',['bDataNotAvail',['../classcom_1_1umc_1_1mlctest_1_1_main_activity.html#ad364b9fb3eeb4150d2bc1d0dd57751c3',1,'com::umc::mlctest::MainActivity']]]
];
