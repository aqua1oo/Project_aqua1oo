var searchData=
[
  ['launchmainsettings',['launchMainSettings',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a10a289c10945db5ac8a8cb935cc97899',1,'com.umc.mlctest.MlcDispActivity.launchMainSettings()'],['../classcom_1_1umc_1_1mlctest_1_1_mlc_set_config_activity.html#adaf1eee2445935feb2daeadd715fd8f5',1,'com.umc.mlctest.MlcSetConfigActivity.launchMainSettings()']]],
  ['launchsurface',['launchSurface',['../classcom_1_1umc_1_1mlctest_1_1_mlc_disp_activity.html#a4a81ce4f9efc147a0e76a41e202079f9',1,'com::umc::mlctest::MlcDispActivity']]]
];
